git log -n 5 --pretty=format:%H
echo ""
